"""PDF report generation."""
