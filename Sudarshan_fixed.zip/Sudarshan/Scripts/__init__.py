"""Sudarshan collection/report modules."""
