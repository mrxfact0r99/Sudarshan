# Fixes applied

All of these were confirmed by actually running the full triage + report
generation before and after the change, not just read from the code.

1. **`Scripts/collectors/processes.py` — corrupted PID on every process record**
   `safe_get()` called every psutil field as a method (`getattr(proc, attr)()`).
   That's correct for `name()`, `exe()`, `cpu_percent()`, etc., but `proc.pid`
   is a plain attribute, not a method — so it raised `'int' object is not
   callable` and every process's `pid` field was replaced with that error
   string. This broke the Process Inventory PDF and silently degraded the
   Process↔Network correlation in the report (it fell back to a weaker
   name-based match and flagged a "Data integrity - corrupted PID field"
   note). Fixed by reading `proc.pid` directly. Verified: all PIDs are now
   real integers and the fallback/degradation notes no longer appear in the
   report.

2. **`Scripts/collectors/history.py` — Firefox history timestamps were fake**
   `firefox_time_to_iso()` was a stub that always returned the literal string
   `"Running....."` instead of converting the timestamp. Every Firefox
   history/search entry showed that placeholder instead of a real date.
   Fixed to properly convert Firefox's `last_visit_date` (microseconds since
   the Unix epoch) to an ISO timestamp.

3. **`Scripts/collectors/commands.py` — Windows RunMRU values could be mangled**
   Used `data.rstrip("\\1")` to strip the trailing `\1` marker Windows adds
   to RunMRU entries. `str.rstrip()` strips a *set* of characters, not a
   literal substring, so any path ending in a backslash or the digit `1`
   (e.g. `...\Users\test1`) got over-trimmed. Fixed with an explicit
   suffix check instead.

4. **`Scripts/gui.py` — GUI could crash on launch on Linux**
   The window-maximize fallback called `self.attributes("-zoomed", True)`
   with no error handling. Many Linux window managers (tiling WMs, minimal
   WMs, or no WM at all) don't support that attribute and raise a
   `TclError`, which would crash the GUI before it ever drew a window.
   Wrapped every maximize attempt safely, with a manual
   screen-size-geometry fallback that always works.

5. **`Scripts/gui.py` — GUI used Windows-only fonts everywhere**
   `"Segoe UI"` and `"Consolas"` don't exist outside Windows; Tk silently
   substitutes something else, which looked inconsistent/unpolished on
   Linux and macOS. The GUI now detects installed fonts at startup and
   picks a real match per OS (e.g. Ubuntu/Cantarell/DejaVu Sans on Linux).

6. **Packaging: added missing `Scripts/__init__.py`, `Scripts/collectors/__init__.py`,
   `Scripts/report/__init__.py`.** The project worked without them via
   Python's implicit namespace packages, but explicit `__init__.py` files
   make the package behave correctly if it's ever installed, vendored, or
   imported from a different working directory.

## Not a bug (by design, worth knowing about)

`Scripts/collectors/execution.py`'s Linux "executed programs" collector
filters out any process owned by `root` and a handful of system daemon
accounts (`is_genuine_linux_process`), to keep the report focused on
user-run programs instead of hundreds of system services. If you run the
whole toolkit as root (e.g. via `sudo python3 main.py`, which the USB/login
collector does recommend for full results), this section will legitimately
show 0 running processes, because *every* process is root-owned in that
scenario. This isn't a defect — it's the same filtering that keeps the
report readable on a normal desktop where you're logged in as yourself and
most user activity isn't root — but it's worth knowing if you specifically
run everything elevated on Linux and see an empty "running_processes"
section.
